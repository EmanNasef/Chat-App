package eman.nasef.chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
